// TODO: Make it actually do something
// See https://gerrit.wikimedia.org/r/c/mediawiki/extensions/MobileFrontend/+/273388/
/* eslint-disable no-unused-vars */
self.addEventListener( 'install', ( event ) => {
	// Perform install steps
} );

self.addEventListener( 'activate', ( event ) => {
	// Perform activate steps
} );

self.addEventListener( 'fetch', ( event ) => {
	// Perform fetch steps (e.g., caching)
} );
