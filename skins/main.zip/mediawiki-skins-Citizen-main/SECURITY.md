# Security Policy

## Reporting a Vulnerability

Please report all vulnerability through GitHub [here](https://github.com/StarCitizenTools/mediawiki-skins-Citizen/security/advisories/new).

The vulnerability will be looked into within a week.

A new release will be cut once the vulnerability is fixed.
